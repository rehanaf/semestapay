import 'package:flutter/material.dart';
import '../../theme/app_theme.dart';
import '../../utils/app_toast.dart';
import 'merchant_success_screen.dart';
import 'merchant_tap_card_screen.dart' show StudentCardData;

class MerchantCardPinScreen extends StatefulWidget {
  final String amount;
  final int rawAmount;
  final String note;
  final StudentCardData studentData;

  const MerchantCardPinScreen({
    super.key,
    required this.amount,
    required this.rawAmount,
    required this.note,
    required this.studentData,
  });

  @override
  State<MerchantCardPinScreen> createState() => _MerchantCardPinScreenState();
}

class _MerchantCardPinScreenState extends State<MerchantCardPinScreen>
    with SingleTickerProviderStateMixin {
  String _pin = '';
  bool _isProcessing = false;

  late final AnimationController _shakeController;
  late final Animation<double> _shakeAnim;

  @override
  void initState() {
    super.initState();
    _shakeController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 400),
    );
    _shakeAnim = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _shakeController, curve: Curves.elasticOut),
    );
  }

  @override
  void dispose() {
    _shakeController.dispose();
    super.dispose();
  }

  void _onPinKey(String digit) {
    if (_pin.length >= 6 || _isProcessing) return;
    setState(() => _pin += digit);
    if (_pin.length == 6) _processPin();
  }

  void _onBackspace() {
    if (_pin.isEmpty || _isProcessing) return;
    setState(() => _pin = _pin.substring(0, _pin.length - 1));
  }

  Future<void> _processPin() async {
    setState(() => _isProcessing = true);

    // Delay singkat sebelum validasi
    await Future.delayed(const Duration(milliseconds: 900));
    if (!mounted) return;

    // Validasi PIN lemah / salah
    if (_pin == '123456') {
      setState(() {
        _isProcessing = false;
        _pin = '';
      });
      _shakeController.forward(from: 0);
      AppToast.show(
        context,
        'PIN salah. Jangan gunakan PIN yang mudah ditebak.',
        type: ToastType.error,
      );
      return;
    }

    // PIN benar → tampilkan dialog verifikasi
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => Dialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 32),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              SizedBox(
                width: 48,
                height: 48,
                child: CircularProgressIndicator(
                  color: AppColors.merchantPrimary,
                  strokeWidth: 3.5,
                ),
              ),
              const SizedBox(height: 20),
              Text(
                'Memverifikasi PIN...',
                style: AppTheme.font(
                  fontSize: 15,
                  fontWeight: FontWeight.w700,
                  color: AppColors.textPrimary,
                ),
              ),
              const SizedBox(height: 6),
              Text(
                'Harap tunggu sebentar',
                style: AppTheme.font(
                  fontSize: 13,
                  color: AppColors.textSecondary,
                ),
              ),
            ],
          ),
        ),
      ),
    );

    await Future.delayed(const Duration(milliseconds: 1500));
    if (!mounted) return;
    Navigator.pop(context);

    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (_) => MerchantSuccessScreen(
          amount: widget.amount,
          rawAmount: widget.rawAmount,
          note: widget.note,
          studentData: widget.studentData,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.merchantBackground,
      appBar: AppBar(
        backgroundColor: AppColors.surface,
        elevation: 0,
        scrolledUnderElevation: 0,
        centerTitle: true,
        leading: IconButton(
          icon: const Icon(Icons.chevron_left_rounded,
              size: 28, color: AppColors.textPrimary),
          onPressed: _isProcessing ? null : () => Navigator.pop(context),
        ),
        title: Text(
          'Masukkan PIN',
          style: AppTheme.font(
            fontSize: 18,
            fontWeight: FontWeight.bold,
            color: AppColors.textPrimary,
          ),
        ),
        actions: const [SizedBox(width: 48)],
      ),
      body: SafeArea(
        child: Column(
          children: [
            // ── Konten Tengah ──────────────────────────────────────
            Expanded(
              child: Center(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    // Icon kunci
                    Container(
                      width: 64,
                      height: 64,
                      decoration: const BoxDecoration(
                        color: AppColors.merchantLightGreen,
                        shape: BoxShape.circle,
                      ),
                      child: const Icon(
                        Icons.lock_rounded,
                        color: AppColors.merchantPrimary,
                        size: 32,
                      ),
                    ),
                    const SizedBox(height: 16),

                    // Nama siswa
                    Text(
                      widget.studentData.name,
                      style: AppTheme.font(
                        fontSize: 18,
                        fontWeight: FontWeight.w700,
                        color: AppColors.textPrimary,
                      ),
                    ),
                    const SizedBox(height: 4),

                    // Total tagihan kecil
                    Text(
                      'Tagihan  Rp ${widget.amount}',
                      style: AppTheme.font(
                        fontSize: 13,
                        fontWeight: FontWeight.w500,
                        color: AppColors.textSecondary,
                      ),
                    ),
                    const SizedBox(height: 32),

                    // Instruksi
                    Text(
                      'Masukkan 6 digit PIN kartu',
                      style: AppTheme.font(
                        fontSize: 13,
                        fontWeight: FontWeight.w500,
                        color: AppColors.textSecondary,
                      ),
                    ),
                    const SizedBox(height: 20),

                    // PIN Dots
                    _buildPinDots(),
                  ],
                ),
              ),
            ),

            // ── Keypad Bawah ───────────────────────────────────────
            _buildKeypad(),
          ],
        ),
      ),
    );
  }

  Widget _buildPinDots() {
    return AnimatedBuilder(
      animation: _shakeAnim,
      builder: (context, child) {
        final offset =
            _shakeAnim.value * 8 * (0.5 - (_shakeAnim.value % 1.0)).sign;
        return Transform.translate(
          offset: Offset(offset, 0),
          child: child,
        );
      },
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: List.generate(6, (i) {
          final filled = i < _pin.length;
          return AnimatedContainer(
            duration: const Duration(milliseconds: 150),
            margin: const EdgeInsets.symmetric(horizontal: 10),
            width: 20,
            height: 20,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: filled ? AppColors.merchantPrimary : Colors.transparent,
              border: Border.all(
                color:
                    filled ? AppColors.merchantPrimary : AppColors.textLight,
                width: 2,
              ),
            ),
          );
        }),
      ),
    );
  }

  Widget _buildKeypad() {
    return Container(
      decoration: BoxDecoration(
        color: AppColors.surface,
        boxShadow: [
          BoxShadow(
            color: AppColors.textPrimary.withValues(alpha: 0.08),
            blurRadius: 18,
            offset: const Offset(0, -4),
          ),
        ],
      ),
      child: SafeArea(
        top: false,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(14, 10, 14, 10),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              _buildKeyRow(['1', '2', '3']),
              const SizedBox(height: 6),
              _buildKeyRow(['4', '5', '6']),
              const SizedBox(height: 6),
              _buildKeyRow(['7', '8', '9']),
              const SizedBox(height: 6),
              Row(
                children: [
                  const Expanded(child: SizedBox()),
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 4),
                      child: _buildKey('0'),
                    ),
                  ),
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 4),
                      child: _buildKey('backspace'),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildKeyRow(List<String> keys) {
    return Row(
      children: keys.map((k) {
        return Expanded(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 4),
            child: _buildKey(k),
          ),
        );
      }).toList(),
    );
  }

  Widget _buildKey(String key) {
    final isBackspace = key == 'backspace';

    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: isBackspace ? _onBackspace : () => _onPinKey(key),
        borderRadius: BorderRadius.circular(12),
        splashColor: AppColors.merchantPrimary.withValues(alpha: 0.12),
        highlightColor: AppColors.merchantPrimary.withValues(alpha: 0.06),
        child: Ink(
          height: 52,
          decoration: BoxDecoration(
            color: const Color(0xFFF7F9FC),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Center(
            child: isBackspace
                ? const Icon(Icons.backspace_outlined,
                    size: 20, color: AppColors.textPrimary)
                : Text(
                    key,
                    style: AppTheme.font(
                      fontSize: 21,
                      fontWeight: FontWeight.w700,
                      color: AppColors.textPrimary,
                    ),
                  ),
          ),
        ),
      ),
    );
  }
}
