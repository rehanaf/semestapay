import 'package:flutter/material.dart';
import 'theme/app_theme.dart';
import 'screens/auth/mode_selection_screen.dart';

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Semestapay',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.light,
      home: const ModeSelectionScreen(),
    );
  }
}
