import 'package:flutter/material.dart';
import '../../theme/app_theme.dart';
import 'login_screen.dart';

class ModeSelectionScreen extends StatelessWidget {
  const ModeSelectionScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: SingleChildScrollView(
          physics: const ClampingScrollPhysics(),
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 28),
              // App Brand Header
              Center(
                child: Column(
                  children: [
                    Container(
                      width: 56,
                      height: 56,
                      decoration: BoxDecoration(
                        gradient: const LinearGradient(
                          colors: [AppColors.primary, AppColors.merchantPrimary],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                        ),
                        borderRadius: BorderRadius.circular(16),
                        boxShadow: [
                          BoxShadow(
                            color: AppColors.primary.withValues(alpha: 0.3),
                            blurRadius: 18,
                            offset: const Offset(0, 6),
                          ),
                        ],
                      ),
                      child: const Icon(
                        Icons.account_balance_rounded,
                        color: Colors.white,
                        size: 30,
                      ),
                    ),
                    const SizedBox(height: 14),
                    Text(
                      'Semestapay Ecosystem',
                      style: AppTheme.font(
                        fontSize: 22,
                        fontWeight: FontWeight.w800,
                        color: AppColors.textPrimary,
                        letterSpacing: -0.3,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      'Pilih layanan yang ingin Anda akses saat ini',
                      textAlign: TextAlign.center,
                      style: AppTheme.font(
                        fontSize: 13,
                        fontWeight: FontWeight.w400,
                        color: AppColors.textSecondary,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 28),

              // ─── CARD 1: PAY MOBILE (BIRU) ───────────────────────────────
              _ModeCard(
                accentColor: AppColors.primary,
                lightBgColor: const Color(0xFFEFF4FF),
                badgeText: 'PRIBADI & NASABAH',
                title: 'Semestapay Mobile',
                subtitle: 'Aplikasi perbankan & transaksi harian perorangan.',
                icon: Icons.phone_android_rounded,
                features: const [
                  'Transfer sesama & antar bank bebas biaya',
                  'Bayar tagihan listrik, air, & pembelian pulsa',
                  'Scan QRIS merchant di mana saja',
                ],
                buttonLabel: 'Masuk ke Semestapay Mobile',
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => const LoginScreen(isMerchant: false),
                    ),
                  );
                },
              ),
              const SizedBox(height: 16),

              // ─── CARD 2: PAY MERCHANT (HIJAU) ────────────────────────────
              _ModeCard(
                accentColor: AppColors.merchantPrimary,
                lightBgColor: AppColors.merchantLightGreen,
                badgeText: 'BISNIS & TOKO',
                title: 'Semestapay Merchant',
                subtitle: 'Solusi kasir & terima pembayaran QRIS usaha Anda.',
                icon: Icons.storefront_rounded,
                features: const [
                  'Buat tagihan & terima pembayaran QRIS instan',
                  'Tarik tunai & settlement otomatis ke rekening',
                  'Kasir POS & laporan omset penjualan harian',
                ],
                buttonLabel: 'Masuk ke Semestapay Merchant',
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => const LoginScreen(isMerchant: true),
                    ),
                  );
                },
              ),
              const SizedBox(height: 24),

              // Footer Security Badge
              Center(
                child: Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const Icon(Icons.verified_user_rounded, size: 14, color: AppColors.merchantPrimary),
                        const SizedBox(width: 6),
                        Text(
                          'Berlisensi Bank Indonesia & Diawasi OJK',
                          style: AppTheme.font(
                            fontSize: 11,
                            fontWeight: FontWeight.w600,
                            color: AppColors.textSecondary,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 6),
                    Text(
                      'Semestapay v2.4.0 • Keamanan 256-bit Enkripsi',
                      style: AppTheme.font(
                        fontSize: 10,
                        color: AppColors.textLight,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 20),
            ],
          ),
        ),
      ),
    );
  }
}

class _ModeCard extends StatelessWidget {
  final Color accentColor;
  final Color lightBgColor;
  final String badgeText;
  final String title;
  final String subtitle;
  final IconData icon;
  final List<String> features;
  final String buttonLabel;
  final VoidCallback onTap;

  const _ModeCard({
    required this.accentColor,
    required this.lightBgColor,
    required this.badgeText,
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.features,
    required this.buttonLabel,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(
          color: accentColor.withValues(alpha: 0.25),
          width: 1.5,
        ),
        boxShadow: [
          BoxShadow(
            color: accentColor.withValues(alpha: 0.08),
            blurRadius: 18,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Top row: Badge + Icon Squircle
          Row(
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: lightBgColor,
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(
                  badgeText,
                  style: AppTheme.font(
                    fontSize: 10,
                    fontWeight: FontWeight.w700,
                    color: accentColor,
                    letterSpacing: 0.5,
                  ),
                ),
              ),
              const Spacer(),
              Container(
                width: 44,
                height: 44,
                decoration: BoxDecoration(
                  color: lightBgColor,
                  borderRadius: BorderRadius.circular(14),
                ),
                child: Icon(icon, color: accentColor, size: 22),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Text(
            title,
            style: AppTheme.font(
              fontSize: 19,
              fontWeight: FontWeight.w800,
              color: AppColors.textPrimary,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            subtitle,
            style: AppTheme.font(
              fontSize: 12,
              fontWeight: FontWeight.w400,
              color: AppColors.textSecondary,
              height: 1.4,
            ),
          ),
          const SizedBox(height: 14),
          // Features list
          Column(
            children: features.map((feat) {
              return Padding(
                padding: const EdgeInsets.only(bottom: 6),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Icon(Icons.check_circle_rounded, size: 14, color: accentColor),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        feat,
                        style: AppTheme.font(
                          fontSize: 12,
                          fontWeight: FontWeight.w500,
                          color: AppColors.textPrimary,
                        ),
                      ),
                    ),
                  ],
                ),
              );
            }).toList(),
          ),
          const SizedBox(height: 16),
          // Enter Button
          SizedBox(
            width: double.infinity,
            height: 46,
            child: ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: accentColor,
                elevation: 0,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
              onPressed: onTap,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    buttonLabel,
                    style: AppTheme.font(
                      fontSize: 13,
                      fontWeight: FontWeight.w700,
                      color: Colors.white,
                    ),
                  ),
                  const SizedBox(width: 6),
                  const Icon(Icons.arrow_forward_rounded, color: Colors.white, size: 16),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
