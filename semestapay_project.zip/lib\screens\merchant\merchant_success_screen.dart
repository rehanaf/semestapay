import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../../theme/app_theme.dart';
import 'merchant_tap_card_screen.dart' show StudentCardData;

class MerchantSuccessScreen extends StatefulWidget {
  final String amount;
  final int rawAmount;
  final String note;
  final StudentCardData studentData;

  const MerchantSuccessScreen({
    super.key,
    required this.amount,
    required this.rawAmount,
    required this.note,
    required this.studentData,
  });

  @override
  State<MerchantSuccessScreen> createState() => _MerchantSuccessScreenState();
}

class _MerchantSuccessScreenState extends State<MerchantSuccessScreen>
    with SingleTickerProviderStateMixin {
  late final AnimationController _checkController;
  late final Animation<double> _checkScale;
  late final Animation<double> _contentFade;

  bool _detailExpanded = false;

  // Simulasi data transaksi
  late final String _trxId;
  late final String _trxTime;

  @override
  void initState() {
    super.initState();

    // Generate ID & waktu
    final now = DateTime.now();
    _trxId = 'TRX-${now.millisecondsSinceEpoch.toString().substring(4)}';
    _trxTime =
        '${_pad(now.day)} ${_monthName(now.month)} ${now.year}, ${_pad(now.hour)}:${_pad(now.minute)} WIB';

    _checkController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 650),
    )..forward();

    _checkScale = CurvedAnimation(
        parent: _checkController, curve: Curves.elasticOut);
    _contentFade = CurvedAnimation(
      parent: _checkController,
      curve: const Interval(0.35, 1.0, curve: Curves.easeOut),
    );
  }

  @override
  void dispose() {
    _checkController.dispose();
    super.dispose();
  }

  String _pad(int v) => v.toString().padLeft(2, '0');

  String _monthName(int m) {
    const months = [
      '', 'Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun',
      'Jul', 'Ags', 'Sep', 'Okt', 'Nov', 'Des',
    ];
    return months[m];
  }

  void _onSelesai() {
    Navigator.of(context).popUntil((route) => route.isFirst);
  }

  void _copyTrxId() {
    Clipboard.setData(ClipboardData(text: _trxId));
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          'ID Transaksi disalin',
          style: AppTheme.font(fontSize: 13, color: Colors.white),
        ),
        backgroundColor: AppColors.merchantPrimary,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        duration: const Duration(seconds: 2),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.merchantBackground,
      appBar: AppBar(
        backgroundColor: AppColors.surface,
        elevation: 0,
        scrolledUnderElevation: 0,
        centerTitle: true,
        leading: IconButton(
          icon: const Icon(Icons.chevron_left_rounded,
              size: 28, color: AppColors.textPrimary),
          onPressed: _onSelesai,
        ),
        title: Text(
          'Bukti Transaksi',
          style: AppTheme.font(
            fontSize: 17,
            fontWeight: FontWeight.bold,
            color: AppColors.textPrimary,
          ),
        ),
        actions: const [SizedBox(width: 48)],
      ),
      body: SafeArea(
        child: Column(
          children: [
            Expanded(
              child: SingleChildScrollView(
                physics: const ClampingScrollPhysics(),
                padding: const EdgeInsets.fromLTRB(20, 20, 20, 16),
                child: FadeTransition(
                  opacity: _contentFade,
                  child: Column(
                    children: [
                      // ── Checkmark ──────────────────────────────────────────
                      ScaleTransition(
                        scale: _checkScale,
                        child: Container(
                          width: 76,
                          height: 76,
                          decoration: BoxDecoration(
                            color: AppColors.merchantLightGreen,
                            shape: BoxShape.circle,
                            boxShadow: [
                              BoxShadow(
                                color: AppColors.merchantPrimary
                                    .withValues(alpha: 0.22),
                                blurRadius: 20,
                                offset: const Offset(0, 6),
                              ),
                            ],
                          ),
                          child: const Icon(
                            Icons.check_circle_rounded,
                            color: AppColors.merchantPrimary,
                            size: 48,
                          ),
                        ),
                      ),
                      const SizedBox(height: 14),

                      // ── Judul ──────────────────────────────────────────────
                      Text(
                        'Transaksi Berhasil!',
                        style: AppTheme.font(
                          fontSize: 22,
                          fontWeight: FontWeight.w800,
                          color: AppColors.textPrimary,
                        ),
                      ),
                      const SizedBox(height: 6),

                      // ── ID Transaksi (tap to copy) ──────────────────────────
                      GestureDetector(
                        onTap: _copyTrxId,
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Text(
                              _trxId,
                              style: AppTheme.font(
                                fontSize: 13,
                                fontWeight: FontWeight.w600,
                                color: AppColors.textSecondary,
                              ),
                            ),
                            const SizedBox(width: 4),
                            const Icon(
                              Icons.copy_rounded,
                              size: 13,
                              color: AppColors.textSecondary,
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 18),

                      // ── Nominal ────────────────────────────────────────────
                      Text(
                        'Rp ${widget.amount}',
                        style: AppTheme.font(
                          fontSize: 32,
                          fontWeight: FontWeight.w800,
                          color: AppColors.textPrimary,
                          letterSpacing: -0.5,
                        ),
                      ),
                      const SizedBox(height: 20),

                      // ── Card Penerima (Siswa) ──────────────────────────────
                      _buildRecipientCard(),
                      const SizedBox(height: 12),

                      // ── Detail Transaksi Accordion ─────────────────────────
                      _buildDetailAccordion(),
                    ],
                  ),
                ),
              ),
            ),

            // ── Tombol Bawah ───────────────────────────────────────────────
            _buildBottomButtons(),
          ],
        ),
      ),
    );
  }

  // ─── Card Penerima ────────────────────────────────────────────────────────────

  Widget _buildRecipientCard() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: AppColors.textPrimary.withValues(alpha: 0.05),
            blurRadius: 12,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: Row(
        children: [
          // Icon sekolah / institusi
          Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(
              color: AppColors.merchantLightGreen,
              borderRadius: BorderRadius.circular(14),
            ),
            child: const Icon(
              Icons.school_rounded,
              color: AppColors.merchantPrimary,
              size: 26,
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  widget.studentData.name,
                  style: AppTheme.font(
                    fontSize: 15,
                    fontWeight: FontWeight.w700,
                    color: AppColors.textPrimary,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  'Kelas ${widget.studentData.schoolClass}',
                  style: AppTheme.font(
                    fontSize: 11,
                    fontWeight: FontWeight.w500,
                    color: AppColors.textSecondary,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  widget.studentData.cardNumber,
                  style: AppTheme.font(
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                    color: AppColors.textSecondary,
                    letterSpacing: 0.5,
                  ),
                ),
              ],
            ),
          ),
          // Badge sukses
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
            decoration: BoxDecoration(
              color: AppColors.merchantLightGreen,
              borderRadius: BorderRadius.circular(6),
            ),
            child: Text(
              'Sukses',
              style: AppTheme.font(
                fontSize: 11,
                fontWeight: FontWeight.w700,
                color: AppColors.merchantPrimary,
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ─── Accordion Detail Transaksi ───────────────────────────────────────────────

  Widget _buildDetailAccordion() {
    return Container(
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: AppColors.textPrimary.withValues(alpha: 0.05),
            blurRadius: 12,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: Column(
        children: [
          // Header accordion
          GestureDetector(
            onTap: () => setState(() => _detailExpanded = !_detailExpanded),
            behavior: HitTestBehavior.opaque,
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
              child: Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(6),
                    decoration: BoxDecoration(
                      color: AppColors.merchantLightGreen,
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: const Icon(
                      Icons.receipt_long_rounded,
                      color: AppColors.merchantPrimary,
                      size: 16,
                    ),
                  ),
                  const SizedBox(width: 10),
                  Text(
                    'Detail Transaksi',
                    style: AppTheme.font(
                      fontSize: 14,
                      fontWeight: FontWeight.w700,
                      color: AppColors.textPrimary,
                    ),
                  ),
                  const Spacer(),
                  AnimatedRotation(
                    turns: _detailExpanded ? 0.5 : 0.0,
                    duration: const Duration(milliseconds: 250),
                    child: const Icon(
                      Icons.keyboard_arrow_down_rounded,
                      color: AppColors.textSecondary,
                      size: 22,
                    ),
                  ),
                ],
              ),
            ),
          ),

          // Konten accordion
          AnimatedCrossFade(
            duration: const Duration(milliseconds: 250),
            crossFadeState: _detailExpanded
                ? CrossFadeState.showFirst
                : CrossFadeState.showSecond,
            firstChild: Padding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
              child: Column(
                children: [
                  const Divider(color: AppColors.divider, height: 1),
                  const SizedBox(height: 14),
                  _row('Waktu Transaksi', _trxTime),
                  _divRow(),
                  _row('No. Referensi', _trxId),
                  _divRow(),
                  _row('Jenis Pembayaran', 'Kartu Siswa NFC'),
                  _divRow(),
                  _row('Kasir', 'Kopi Reyhan & Bakery'),
                  _divRow(),
                  _row('MID / TID', '9831 2049 8812 / 002910'),
                  _divRow(),
                  _row('Terminal', '#01'),
                  if (widget.note.isNotEmpty) ...[
                    _divRow(),
                    _row('Catatan', widget.note),
                  ],
                  _divRow(),
                  _row('Biaya Transaksi', 'Gratis (Rp 0)',
                      valueColor: AppColors.merchantPrimary),
                  const SizedBox(height: 12),
                  const Divider(color: AppColors.divider, height: 1),
                  const SizedBox(height: 12),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        'Total Transaksi',
                        style: AppTheme.font(
                          fontSize: 14,
                          fontWeight: FontWeight.w700,
                          color: AppColors.textPrimary,
                        ),
                      ),
                      Text(
                        'Rp ${widget.amount}',
                        style: AppTheme.font(
                          fontSize: 16,
                          fontWeight: FontWeight.w800,
                          color: AppColors.textPrimary,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            secondChild: const SizedBox(width: double.infinity),
          ),
        ],
      ),
    );
  }

  Widget _row(String label, String value, {Color? valueColor}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            label,
            style: AppTheme.font(
              fontSize: 13,
              color: AppColors.textSecondary,
            ),
          ),
          const SizedBox(width: 12),
          Flexible(
            child: Text(
              value,
              textAlign: TextAlign.end,
              style: AppTheme.font(
                fontSize: 13,
                fontWeight: FontWeight.w600,
                color: valueColor ?? AppColors.textPrimary,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _divRow() => const SizedBox(height: 2);

  // ─── Tombol Bawah ─────────────────────────────────────────────────────────────

  Widget _buildBottomButtons() {
    return Container(
      padding: const EdgeInsets.fromLTRB(20, 10, 20, 16),
      decoration: BoxDecoration(
        color: AppColors.surface,
        boxShadow: [
          BoxShadow(
            color: AppColors.textPrimary.withValues(alpha: 0.06),
            blurRadius: 16,
            offset: const Offset(0, -4),
          ),
        ],
      ),
      child: SafeArea(
        top: false,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // Tombol Selesai
            SizedBox(
              width: double.infinity,
              height: 50,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.merchantPrimary,
                  elevation: 0,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(14)),
                ),
                onPressed: _onSelesai,
                child: Text(
                  'Selesai',
                  style: AppTheme.font(
                    fontSize: 15,
                    fontWeight: FontWeight.w700,
                    color: Colors.white,
                  ),
                ),
              ),
            ),
            const SizedBox(height: 8),

            // Tombol Bagikan
            SizedBox(
              width: double.infinity,
              height: 44,
              child: OutlinedButton.icon(
                style: OutlinedButton.styleFrom(
                  foregroundColor: AppColors.merchantPrimary,
                  side: const BorderSide(color: AppColors.divider),
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(14)),
                ),
                icon: const Icon(Icons.share_outlined, size: 17),
                label: Text(
                  'Bagikan Bukti Transaksi',
                  style: AppTheme.font(
                    fontSize: 13,
                    fontWeight: FontWeight.w600,
                    color: AppColors.merchantPrimary,
                  ),
                ),
                onPressed: () {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text(
                        'Bukti transaksi siap dibagikan',
                        style: AppTheme.font(fontSize: 13, color: Colors.white),
                      ),
                      backgroundColor: AppColors.merchantPrimary,
                      behavior: SnackBarBehavior.floating,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10)),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
