import 'package:flutter/material.dart';
import '../../theme/app_theme.dart';
import 'merchant_card_pin_screen.dart';

// ─── Model Data Siswa ─────────────────────────────────────────────────────────

class StudentCardData {
  final String name;
  final int balance;
  final String cardNumber;
  final String schoolClass;

  const StudentCardData({
    required this.name,
    required this.balance,
    required this.cardNumber,
    required this.schoolClass,
  });
}

// ─── Screen ───────────────────────────────────────────────────────────────────

class MerchantTapCardScreen extends StatefulWidget {
  final String amount;
  final int rawAmount;
  final String note;

  const MerchantTapCardScreen({
    super.key,
    required this.amount,
    required this.rawAmount,
    required this.note,
  });

  @override
  State<MerchantTapCardScreen> createState() => _MerchantTapCardScreenState();
}

class _MerchantTapCardScreenState extends State<MerchantTapCardScreen>
    with TickerProviderStateMixin {
  late final AnimationController _rippleController;
  late final AnimationController _tapController;
  late final Animation<double> _glowAnim;

  bool _isTapping = false;
  bool _tapDone = false;
  bool _tapFailed = false;

  static const _studentData = StudentCardData(
    name: 'Reyhan Pratama',
    balance: 150000,
    cardNumber: '•••• •••• 4821',
    schoolClass: 'XI IPA 3',
  );

  @override
  void initState() {
    super.initState();

    _rippleController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1600),
    )..repeat();

    _tapController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 600),
    );

    _glowAnim = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(
        parent: _tapController,
        curve: const Interval(0.5, 1.0, curve: Curves.easeOut),
      ),
    );
  }

  @override
  void dispose() {
    _rippleController.dispose();
    _tapController.dispose();
    super.dispose();
  }

  // ── Simulasi Berhasil ───────────────────────────────────────────────────────

  Future<void> _simulateTapSuccess() async {
    if (_isTapping) return;
    setState(() {
      _isTapping = true;
      _tapFailed = false;
    });

    await _tapController.forward();
    setState(() => _tapDone = true);

    await Future.delayed(const Duration(milliseconds: 500));
    if (!mounted) return;

    _showStudentBottomSheet(success: true);
  }

  // ── Simulasi Gagal ──────────────────────────────────────────────────────────

  Future<void> _simulateTapFailed() async {
    if (_isTapping) return;
    setState(() {
      _isTapping = true;
      _tapFailed = true;
      _tapDone = false;
    });

    // Animasi singkat lalu reset
    await Future.delayed(const Duration(milliseconds: 600));
    if (!mounted) return;

    _tapController.reset();
    setState(() => _isTapping = false);

    _showStudentBottomSheet(success: false);
  }

  // ── Bottom Sheet ─────────────────────────────────────────────────────────────

  void _showStudentBottomSheet({required bool success}) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => _TapResultBottomSheet(
        success: success,
        studentData: _studentData,
        rawAmount: widget.rawAmount,
        amount: widget.amount,
        onProceed: _proceedToPin,
        onRetry: () {
          Navigator.pop(context);
          _resetState();
        },
        onCancel: () {
          Navigator.pop(context);   // tutup sheet
          Navigator.pop(context);   // balik ke transaksi screen
        },
      ),
    ).then((_) {
      // Jika sheet ditutup tanpa aksi, reset state
      if (mounted && !_tapDone) _resetState();
    });
  }

  void _resetState() {
    _tapController.reset();
    setState(() {
      _isTapping = false;
      _tapDone = false;
      _tapFailed = false;
    });
  }

  void _proceedToPin() {
    Navigator.pop(context); // tutup bottom sheet
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (_) => MerchantCardPinScreen(
          amount: widget.amount,
          rawAmount: widget.rawAmount,
          note: widget.note,
          studentData: _studentData,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.merchantBackground,
      appBar: AppBar(
        backgroundColor: AppColors.surface,
        elevation: 0,
        scrolledUnderElevation: 0,
        centerTitle: true,
        leading: IconButton(
          icon: const Icon(Icons.chevron_left_rounded,
              size: 28, color: AppColors.textPrimary),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(
          'Tap Kartu Siswa',
          style: AppTheme.font(
            fontSize: 18,
            fontWeight: FontWeight.bold,
            color: AppColors.textPrimary,
          ),
        ),
        actions: const [SizedBox(width: 48)],
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(16, 16, 16, 24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              _buildStoreCard(),
              const SizedBox(height: 12),
              _buildTagihanCard(),
              const SizedBox(height: 32),

              // NFC Area
              _buildNfcArea(),
              const SizedBox(height: 20),

              // Instruksi
              _buildInstruction(),
              const SizedBox(height: 32),

              // Tombol Simulasi (hanya tampil jika belum tap)
              if (!_isTapping && !_tapDone) ...[
                _buildSimulateButton(
                  label: 'Simulasi Tap Berhasil',
                  icon: Icons.wifi_rounded,
                  color: AppColors.merchantPrimary,
                  onTap: _simulateTapSuccess,
                ),
                const SizedBox(height: 10),
                _buildSimulateButton(
                  label: 'Simulasi Tap Gagal',
                  icon: Icons.wifi_off_rounded,
                  color: AppColors.error,
                  onTap: _simulateTapFailed,
                  outlined: true,
                ),
              ],

              // Loading saat tapping
              if (_isTapping && !_tapDone && !_tapFailed)
                const Center(
                  child: Padding(
                    padding: EdgeInsets.symmetric(vertical: 8),
                    child: CircularProgressIndicator(
                      color: AppColors.merchantPrimary,
                      strokeWidth: 3,
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }

  // ─── Card Toko ──────────────────────────────────────────────────────────────

  Widget _buildStoreCard() {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: AppColors.textPrimary.withValues(alpha: 0.05),
            blurRadius: 10,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 42,
            height: 42,
            decoration: const BoxDecoration(
              color: AppColors.merchantLightGreen,
              shape: BoxShape.circle,
            ),
            child: const Icon(Icons.storefront_rounded,
                color: AppColors.merchantPrimary, size: 22),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Kopi Reyhan & Bakery',
                  style: AppTheme.font(
                    fontSize: 14,
                    fontWeight: FontWeight.w700,
                    color: AppColors.textPrimary,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  'MID: 9831 2049 8812 • Terminal #01',
                  style: AppTheme.font(
                    fontSize: 11,
                    fontWeight: FontWeight.w500,
                    color: AppColors.textSecondary,
                  ),
                ),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
            decoration: BoxDecoration(
              color: AppColors.merchantLightGreen,
              borderRadius: BorderRadius.circular(6),
            ),
            child: Text(
              'Kasir POS',
              style: AppTheme.font(
                fontSize: 10,
                fontWeight: FontWeight.w700,
                color: AppColors.merchantPrimary,
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ─── Card Tagihan ────────────────────────────────────────────────────────────

  Widget _buildTagihanCard() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: AppColors.textPrimary.withValues(alpha: 0.05),
            blurRadius: 10,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Total Tagihan',
                  style: AppTheme.font(
                    fontSize: 11,
                    fontWeight: FontWeight.w500,
                    color: AppColors.textSecondary,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  'Rp ${widget.amount}',
                  style: AppTheme.font(
                    fontSize: 22,
                    fontWeight: FontWeight.w800,
                    color: AppColors.textPrimary,
                  ),
                ),
              ],
            ),
          ),
          if (widget.note.isNotEmpty)
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
              decoration: BoxDecoration(
                color: AppColors.merchantLightGreen,
                borderRadius: BorderRadius.circular(8),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Icon(Icons.receipt_long_rounded,
                      size: 13, color: AppColors.merchantPrimary),
                  const SizedBox(width: 4),
                  Text(
                    widget.note,
                    style: AppTheme.font(
                      fontSize: 11,
                      fontWeight: FontWeight.w600,
                      color: AppColors.merchantPrimary,
                    ),
                  ),
                ],
              ),
            ),
        ],
      ),
    );
  }

  // ─── NFC Area ────────────────────────────────────────────────────────────────

  Widget _buildNfcArea() {
    final isError = _tapFailed;
    final isDone = _tapDone;

    return Center(
      child: AnimatedBuilder(
        animation: _glowAnim,
        builder: (context, child) {
          Color bgColor;
          Color glowColor;
          if (isError) {
            bgColor = AppColors.error.withValues(alpha: 0.08);
            glowColor = Colors.transparent;
          } else if (isDone) {
            bgColor = AppColors.merchantLightGreen;
            glowColor = AppColors.merchantPrimary.withValues(alpha: 0.25 * _glowAnim.value);
          } else {
            bgColor = const Color(0xFFF0F4FF);
            glowColor = AppColors.primary.withValues(alpha: 0.08);
          }

          return Container(
            width: 180,
            height: 180,
            decoration: BoxDecoration(
              color: bgColor,
              shape: BoxShape.circle,
              boxShadow: [
                BoxShadow(
                  color: glowColor,
                  blurRadius: isDone ? 40 : 20,
                  spreadRadius: isDone ? 8 : 0,
                ),
              ],
            ),
            child: Stack(
              alignment: Alignment.center,
              children: [
                CustomPaint(
                  size: const Size(160, 160),
                  painter: _NfcRipplePainter(
                    animation: _rippleController,
                    glowing: isDone,
                    error: isError,
                  ),
                ),
                AnimatedContainer(
                  duration: const Duration(milliseconds: 400),
                  width: 64,
                  height: 64,
                  decoration: BoxDecoration(
                    color: isError
                        ? AppColors.error.withValues(alpha: 0.15)
                        : isDone
                            ? AppColors.merchantPrimary
                            : AppColors.primary.withValues(alpha: 0.1),
                    shape: BoxShape.circle,
                  ),
                  child: Icon(
                    isError
                        ? Icons.wifi_off_rounded
                        : isDone
                            ? Icons.check_rounded
                            : Icons.wifi_rounded,
                    color: isError
                        ? AppColors.error
                        : isDone
                            ? Colors.white
                            : AppColors.primary,
                    size: 32,
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  // ─── Instruksi ───────────────────────────────────────────────────────────────

  Widget _buildInstruction() {
    String title;
    String subtitle;
    Color titleColor;

    if (_tapFailed) {
      title = 'Kartu Tidak Terbaca';
      subtitle = 'Pastikan kartu didekatkan dengan\nbenar, lalu coba lagi';
      titleColor = AppColors.error;
    } else if (_tapDone) {
      title = 'Kartu Terdeteksi! ✓';
      subtitle = 'Membaca data kartu siswa...';
      titleColor = AppColors.merchantPrimary;
    } else {
      title = 'Tempelkan Kartu Siswa';
      subtitle = 'Dekatkan kartu RFID / NFC siswa ke\narea pembaca di atas';
      titleColor = AppColors.textPrimary;
    }

    return AnimatedSwitcher(
      duration: const Duration(milliseconds: 300),
      child: Column(
        key: ValueKey('$_tapDone-$_tapFailed'),
        children: [
          Text(
            title,
            style: AppTheme.font(
              fontSize: 16,
              fontWeight: FontWeight.w700,
              color: titleColor,
            ),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 4),
          Text(
            subtitle,
            style: AppTheme.font(
              fontSize: 13,
              color: AppColors.textSecondary,
              height: 1.5,
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  // ─── Tombol Simulasi ─────────────────────────────────────────────────────────

  Widget _buildSimulateButton({
    required String label,
    required IconData icon,
    required Color color,
    required VoidCallback onTap,
    bool outlined = false,
  }) {
    if (outlined) {
      return SizedBox(
        height: 48,
        child: OutlinedButton.icon(
          icon: Icon(icon, size: 18, color: color),
          label: Text(
            label,
            style: AppTheme.font(
              fontSize: 14,
              fontWeight: FontWeight.w700,
              color: color,
            ),
          ),
          style: OutlinedButton.styleFrom(
            foregroundColor: color,
            side: BorderSide(color: color.withValues(alpha: 0.5), width: 1.5),
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(14)),
          ),
          onPressed: onTap,
        ),
      );
    }

    return SizedBox(
      height: 48,
      child: ElevatedButton.icon(
        icon: Icon(icon, size: 18, color: Colors.white),
        label: Text(
          label,
          style: AppTheme.font(
            fontSize: 14,
            fontWeight: FontWeight.w700,
            color: Colors.white,
          ),
        ),
        style: ElevatedButton.styleFrom(
          backgroundColor: color,
          elevation: 0,
          shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(14)),
          shadowColor: color.withValues(alpha: 0.3),
        ),
        onPressed: onTap,
      ),
    );
  }
}

// ─── Bottom Sheet Hasil Tap ───────────────────────────────────────────────────

class _TapResultBottomSheet extends StatelessWidget {
  final bool success;
  final StudentCardData studentData;
  final int rawAmount;
  final String amount;
  final VoidCallback onProceed;
  final VoidCallback onRetry;
  final VoidCallback onCancel;

  const _TapResultBottomSheet({
    required this.success,
    required this.studentData,
    required this.rawAmount,
    required this.amount,
    required this.onProceed,
    required this.onRetry,
    required this.onCancel,
  });

  String _formatRupiah(int v) {
    final s = v.toString();
    final buf = StringBuffer();
    for (int i = 0; i < s.length; i++) {
      if (i > 0 && (s.length - i) % 3 == 0) buf.write('.');
      buf.write(s[i]);
    }
    return buf.toString();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      padding: EdgeInsets.fromLTRB(
        20,
        16,
        20,
        MediaQuery.of(context).padding.bottom + 20,
      ),
      child: success ? _buildSuccess(context) : _buildFailed(context),
    );
  }

  // ── Konten Berhasil ──────────────────────────────────────────────────────────

  Widget _buildSuccess(BuildContext context) {
    final saldo = studentData.balance;
    final cukup = saldo >= rawAmount;

    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        // Handle bar
        _handle(),
        const SizedBox(height: 16),

        // Header
        Row(
          children: [
            Container(
              width: 44,
              height: 44,
              decoration: BoxDecoration(
                color: AppColors.merchantLightGreen,
                borderRadius: BorderRadius.circular(12),
              ),
              child: const Icon(Icons.school_rounded,
                  color: AppColors.merchantPrimary, size: 24),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    studentData.name,
                    style: AppTheme.font(
                      fontSize: 16,
                      fontWeight: FontWeight.w700,
                      color: AppColors.textPrimary,
                    ),
                  ),
                  Text(
                    'Kelas ${studentData.schoolClass} · ${studentData.cardNumber}',
                    style: AppTheme.font(
                      fontSize: 11,
                      fontWeight: FontWeight.w500,
                      color: AppColors.textSecondary,
                    ),
                  ),
                ],
              ),
            ),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
              decoration: BoxDecoration(
                color: AppColors.merchantLightGreen,
                borderRadius: BorderRadius.circular(6),
              ),
              child: Text(
                '✓ Terbaca',
                style: AppTheme.font(
                  fontSize: 10,
                  fontWeight: FontWeight.w700,
                  color: AppColors.merchantPrimary,
                ),
              ),
            ),
          ],
        ),

        const SizedBox(height: 16),
        const Divider(color: AppColors.divider, height: 1),
        const SizedBox(height: 16),

        // Saldo & Tagihan
        Row(
          children: [
            Expanded(
              child: _infoItem(
                label: 'Sisa Saldo',
                value: 'Rp ${_formatRupiah(saldo)}',
                valueColor: cukup ? AppColors.merchantPrimary : AppColors.error,
              ),
            ),
            Container(width: 1, height: 40, color: AppColors.divider),
            const SizedBox(width: 16),
            Expanded(
              child: _infoItem(
                label: 'Tagihan',
                value: 'Rp $amount',
                valueColor: AppColors.textPrimary,
              ),
            ),
          ],
        ),

        const SizedBox(height: 12),

        // Status badge
        Container(
          width: double.infinity,
          padding: const EdgeInsets.symmetric(vertical: 10),
          decoration: BoxDecoration(
            color: cukup
                ? AppColors.merchantLightGreen
                : AppColors.error.withValues(alpha: 0.08),
            borderRadius: BorderRadius.circular(10),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                cukup ? Icons.check_circle_rounded : Icons.warning_rounded,
                size: 15,
                color: cukup ? AppColors.merchantPrimary : AppColors.error,
              ),
              const SizedBox(width: 6),
              Text(
                cukup
                    ? 'Saldo mencukupi — lanjutkan ke PIN'
                    : 'Saldo tidak mencukupi untuk transaksi ini',
                style: AppTheme.font(
                  fontSize: 12,
                  fontWeight: FontWeight.w700,
                  color: cukup ? AppColors.merchantPrimary : AppColors.error,
                ),
              ),
            ],
          ),
        ),

        const SizedBox(height: 20),

        // Tombol
        SizedBox(
          width: double.infinity,
          height: 50,
          child: ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: cukup
                  ? AppColors.merchantPrimary
                  : const Color(0xFFD3D8E8),
              elevation: 0,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(14)),
            ),
            onPressed: cukup ? onProceed : null,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  'Lanjutkan ke Input PIN',
                  style: AppTheme.font(
                    fontSize: 15,
                    fontWeight: FontWeight.w700,
                    color: Colors.white,
                  ),
                ),
                const SizedBox(width: 6),
                const Icon(Icons.arrow_forward_rounded,
                    size: 18, color: Colors.white),
              ],
            ),
          ),
        ),

        if (!cukup) ...[
          const SizedBox(height: 10),
          SizedBox(
            width: double.infinity,
            height: 46,
            child: OutlinedButton(
              style: OutlinedButton.styleFrom(
                side: const BorderSide(color: AppColors.divider),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(14)),
              ),
              onPressed: onCancel,
              child: Text(
                'Batalkan Transaksi',
                style: AppTheme.font(
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                  color: AppColors.textSecondary,
                ),
              ),
            ),
          ),
        ],
      ],
    );
  }

  // ── Konten Gagal ─────────────────────────────────────────────────────────────

  Widget _buildFailed(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        _handle(),
        const SizedBox(height: 20),

        // Icon error
        Container(
          width: 64,
          height: 64,
          decoration: BoxDecoration(
            color: AppColors.error.withValues(alpha: 0.1),
            shape: BoxShape.circle,
          ),
          child: const Icon(
            Icons.wifi_off_rounded,
            color: AppColors.error,
            size: 32,
          ),
        ),
        const SizedBox(height: 14),

        Text(
          'Kartu Tidak Terbaca',
          style: AppTheme.font(
            fontSize: 18,
            fontWeight: FontWeight.w700,
            color: AppColors.textPrimary,
          ),
        ),
        const SizedBox(height: 6),

        Text(
          'Kartu siswa tidak dapat dideteksi oleh\nterminal. Pastikan kartu dalam kondisi baik\ndan coba tempelkan kembali.',
          style: AppTheme.font(
            fontSize: 13,
            color: AppColors.textSecondary,
            height: 1.6,
          ),
          textAlign: TextAlign.center,
        ),
        const SizedBox(height: 24),

        SizedBox(
          width: double.infinity,
          height: 50,
          child: ElevatedButton.icon(
            icon: const Icon(Icons.refresh_rounded, size: 18, color: Colors.white),
            label: Text(
              'Coba Lagi',
              style: AppTheme.font(
                fontSize: 15,
                fontWeight: FontWeight.w700,
                color: Colors.white,
              ),
            ),
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.merchantPrimary,
              elevation: 0,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(14)),
            ),
            onPressed: onRetry,
          ),
        ),
        const SizedBox(height: 10),
        SizedBox(
          width: double.infinity,
          height: 46,
          child: OutlinedButton(
            style: OutlinedButton.styleFrom(
              side: const BorderSide(color: AppColors.divider),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(14)),
            ),
            onPressed: onCancel,
            child: Text(
              'Batalkan Transaksi',
              style: AppTheme.font(
                fontSize: 14,
                fontWeight: FontWeight.w600,
                color: AppColors.textSecondary,
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _handle() {
    return Center(
      child: Container(
        width: 36,
        height: 4,
        decoration: BoxDecoration(
          color: AppColors.divider,
          borderRadius: BorderRadius.circular(2),
        ),
      ),
    );
  }

  Widget _infoItem({
    required String label,
    required String value,
    required Color valueColor,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: AppTheme.font(
            fontSize: 11,
            fontWeight: FontWeight.w500,
            color: AppColors.textSecondary,
          ),
        ),
        const SizedBox(height: 3),
        Text(
          value,
          style: AppTheme.font(
            fontSize: 16,
            fontWeight: FontWeight.w800,
            color: valueColor,
          ),
        ),
      ],
    );
  }
}

// ─── Custom Painter Ripple NFC ───────────────────────────────────────────────

class _NfcRipplePainter extends CustomPainter {
  final Animation<double> animation;
  final bool glowing;
  final bool error;

  _NfcRipplePainter({
    required this.animation,
    required this.glowing,
    this.error = false,
  }) : super(repaint: animation);

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final maxRadius = size.width / 2;

    final baseColor = error
        ? AppColors.error
        : glowing
            ? AppColors.merchantPrimary
            : AppColors.primary;

    for (int i = 0; i < 3; i++) {
      final phase = (animation.value + i / 3) % 1.0;
      final radius = maxRadius * phase;
      final opacity = (1.0 - phase) * (glowing ? 0.45 : error ? 0.3 : 0.15);

      final paint = Paint()
        ..color = baseColor.withValues(alpha: opacity)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2;

      canvas.drawCircle(center, radius, paint);
    }
  }

  @override
  bool shouldRepaint(_NfcRipplePainter oldDelegate) =>
      oldDelegate.glowing != glowing || oldDelegate.error != error;
}
