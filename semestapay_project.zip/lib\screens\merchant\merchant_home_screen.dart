import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../../theme/app_theme.dart';
import '../auth/mode_selection_screen.dart';
import 'merchant_transaction_screen.dart';

class MerchantHomeScreen extends StatefulWidget {
  const MerchantHomeScreen({super.key});

  @override
  State<MerchantHomeScreen> createState() => _MerchantHomeScreenState();
}

class _MerchantHomeScreenState extends State<MerchantHomeScreen> {
  int _currentIndex = 0;
  late final List<Widget> _pages = [
    const _MerchantHomePage(),
    const _MerchantReportsPage(),
    const _MerchantProductsPage(),
    _MerchantSettingsPage(onLogout: _showLogoutDialog),
  ];

  void _showLogoutDialog() {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        backgroundColor: AppColors.surface,
        title: Text(
          'Keluar dari Merchant',
          style: AppTheme.font(
            fontSize: 18,
            fontWeight: FontWeight.w700,
            color: AppColors.textPrimary,
          ),
        ),
        content: Text(
          'Apakah Anda ingin keluar dari akun Semestapay Merchant?',
          style: AppTheme.font(
            fontSize: 14,
            color: AppColors.textSecondary,
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: Text(
              'Batal',
              style: AppTheme.font(
                fontSize: 14,
                fontWeight: FontWeight.w600,
                color: AppColors.textSecondary,
              ),
            ),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.error,
              elevation: 0,
              minimumSize: const Size(90, 40),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10),
              ),
            ),
            onPressed: () {
              Navigator.pop(ctx);
              Navigator.pushAndRemoveUntil(
                context,
                MaterialPageRoute(builder: (_) => const ModeSelectionScreen()),
                (route) => false,
              );
            },
            child: Text(
              'Keluar',
              style: AppTheme.font(
                fontSize: 14,
                fontWeight: FontWeight.w600,
                color: Colors.white,
              ),
            ),
          ),
        ],
      ),
    );
  }

  PreferredSizeWidget? _buildAppBar() {
    if (_currentIndex != 0) {
      const titles = ['Beranda', 'Laporan', 'Produk', 'Pengaturan'];
      return AppBar(
        backgroundColor: AppColors.surface,
        elevation: 0,
        scrolledUnderElevation: 0,
        centerTitle: true,
        leading: IconButton(
          icon: const Icon(Icons.chevron_left_rounded, size: 28, color: AppColors.textPrimary),
          onPressed: () => setState(() => _currentIndex = 0),
        ),
        title: Text(
          titles[_currentIndex],
          style: AppTheme.font(
            fontSize: 18,
            fontWeight: FontWeight.bold,
            color: AppColors.textPrimary,
          ),
        ),
        actions: const [
          SizedBox(width: 48),
        ],
      );
    }

    return AppBar(
      backgroundColor: AppColors.surface,
      elevation: 0,
      scrolledUnderElevation: 0,
      automaticallyImplyLeading: false,
      titleSpacing: 16,
      toolbarHeight: 70,
      title: Row(
        children: [
          // Avatar Toko Lingkaran Hijau
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: const LinearGradient(
                colors: [AppColors.merchantPrimary, Color(0xFF00C896)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              boxShadow: [
                BoxShadow(
                  color: AppColors.merchantPrimary.withValues(alpha: 0.25),
                  blurRadius: 10,
                  offset: const Offset(0, 3),
                ),
              ],
            ),
            child: const Icon(Icons.storefront_rounded, color: Colors.white, size: 24),
          ),
          const SizedBox(width: 12),
          // Nama Toko & MID
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Row(
                  children: [
                    Flexible(
                      child: Text(
                        'Kopi Reyhan & Bakery',
                        overflow: TextOverflow.ellipsis,
                        style: AppTheme.font(
                          fontSize: 15,
                          fontWeight: FontWeight.w700,
                          color: AppColors.textPrimary,
                        ),
                      ),
                    ),
                    const SizedBox(width: 4),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                      decoration: BoxDecoration(
                        color: AppColors.merchantLightGreen,
                        borderRadius: BorderRadius.circular(6),
                      ),
                      child: Text(
                        'Buka',
                        style: AppTheme.font(
                          fontSize: 9,
                          fontWeight: FontWeight.w700,
                          color: AppColors.merchantPrimary,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 2),
                Text(
                  'MID: 9831 2049 8812',
                  style: AppTheme.font(
                    fontSize: 11,
                    fontWeight: FontWeight.w500,
                    color: AppColors.textSecondary,
                    letterSpacing: 0.3,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
      actions: [
        _MerchantAppBarButton(
          icon: Icons.notifications_none_rounded,
          badge: 2,
          onTap: () {},
        ),
        const SizedBox(width: 16),
      ],
    );
  }

  void _openNewTransactionSheet() {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => const MerchantTransactionScreen()),
    );
  }

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.dark,
    ));

    return Scaffold(
      backgroundColor: AppColors.merchantBackground,
      appBar: _buildAppBar(),
      body: IndexedStack(
        index: _currentIndex,
        children: _pages,
      ),
      bottomNavigationBar: _buildBottomNav(),
    );
  }

  Widget _buildBottomNav() {
    return Container(
      color: Colors.transparent,
      child: SafeArea(
        top: false,
        child: SizedBox(
          height: 80,
          child: Stack(
            clipBehavior: Clip.none,
            alignment: Alignment.bottomCenter,
            children: [
              // Navigation bar background
              Container(
                height: 64,
                decoration: BoxDecoration(
                  color: AppColors.surface,
                  boxShadow: [
                    BoxShadow(
                      color: AppColors.textPrimary.withValues(alpha: 0.08),
                      blurRadius: 24,
                      offset: const Offset(0, -4),
                    ),
                  ],
                ),
                child: Row(
                  children: [
                    Expanded(
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceAround,
                        children: [
                          _MerchantNavItem(
                            icon: Icons.storefront_rounded,
                            label: 'Beranda',
                            isActive: _currentIndex == 0,
                            onTap: () => setState(() => _currentIndex = 0),
                          ),
                          _MerchantNavItem(
                            icon: Icons.bar_chart_rounded,
                            label: 'Laporan',
                            isActive: _currentIndex == 1,
                            onTap: () => setState(() => _currentIndex = 1),
                          ),
                        ],
                      ),
                    ),
                    // Ruang tengah untuk tombol TRANSAKSI timbul
                    const SizedBox(width: 76),
                    Expanded(
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceAround,
                        children: [
                          _MerchantNavItem(
                            icon: Icons.inventory_2_outlined,
                            label: 'Produk',
                            isActive: _currentIndex == 2,
                            onTap: () => setState(() => _currentIndex = 2),
                          ),
                          _MerchantNavItem(
                            icon: Icons.store_mall_directory_outlined,
                            label: 'Toko',
                            isActive: _currentIndex == 3,
                            onTap: () => setState(() => _currentIndex = 3),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),

              // Tombol TRANSAKSI Timbul Bentuk SQUIRCLE HIJAU
              Positioned(
                top: 0,
                child: GestureDetector(
                  onTap: _openNewTransactionSheet,
                  behavior: HitTestBehavior.opaque,
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Container(
                        width: 58,
                        height: 58,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(20), // SQUIRCLE SHAPE
                          gradient: const LinearGradient(
                            colors: [AppColors.merchantPrimary, Color(0xFF00875A)],
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                          ),
                          border: Border.all(
                            color: AppColors.surface,
                            width: 3.5,
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: AppColors.merchantPrimary.withValues(alpha: 0.45),
                              blurRadius: 18,
                              offset: const Offset(0, 8),
                            ),
                          ],
                        ),
                        child: const Icon(
                          Icons.add_card_rounded,
                          color: Colors.white,
                          size: 27,
                        ),
                      ),
                      const SizedBox(height: 3),
                      Text(
                        'Transaksi',
                        style: AppTheme.font(
                          fontSize: 10,
                          fontWeight: FontWeight.w700,
                          color: AppColors.merchantPrimary,
                          letterSpacing: 0.2,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ─── MERCHANT HOME PAGE ─────────────────────────────────────────────────────

class _MerchantHomePage extends StatefulWidget {
  const _MerchantHomePage();

  @override
  State<_MerchantHomePage> createState() => _MerchantHomePageState();
}

class _MerchantHomePageState extends State<_MerchantHomePage> {
  bool _balanceVisible = true;

  void _openNewTransaction() {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => const MerchantTransactionScreen()),
    );
  }

  void _openWithdrawModal() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => const _WithdrawModal(),
    );
  }

  void _openHistoryModal() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => const _TransactionHistoryModal(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return CustomScrollView(
      physics: const ClampingScrollPhysics(),
      slivers: [
        SliverToBoxAdapter(child: _buildBalanceCard()),
        SliverToBoxAdapter(child: _buildTodayStats()),
        SliverToBoxAdapter(child: _buildShortcuts()),
        SliverToBoxAdapter(child: _buildPromoSection()),
        SliverToBoxAdapter(child: _buildRecentTransactions()),
        const SliverToBoxAdapter(child: SizedBox(height: 28)),
      ],
    );
  }

  Widget _buildBalanceCard() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(24),
          gradient: const LinearGradient(
            colors: [Color(0xFF00A86B), Color(0xFF006C44)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          boxShadow: [
            BoxShadow(
              color: AppColors.merchantPrimary.withValues(alpha: 0.38),
              blurRadius: 28,
              offset: const Offset(0, 10),
            ),
          ],
        ),
        child: Stack(
          children: [
            // Decorative background circles
            Positioned(
              right: -30,
              top: -30,
              child: Container(
                width: 160,
                height: 160,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: Colors.white.withValues(alpha: 0.08),
                ),
              ),
            ),
            Positioned(
              right: 40,
              bottom: -50,
              child: Container(
                width: 130,
                height: 130,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: Colors.white.withValues(alpha: 0.08),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Row: Saldo Merchant + Eye icon + Spacer + Chevron icon di pojok kanan
                  Row(
                    children: [
                      Text(
                        'Saldo Siap Tarik',
                        style: AppTheme.font(
                          fontSize: 12,
                          fontWeight: FontWeight.w500,
                          color: Colors.white.withValues(alpha: 0.85),
                        ),
                      ),
                      const SizedBox(width: 8),
                      GestureDetector(
                        onTap: () =>
                            setState(() => _balanceVisible = !_balanceVisible),
                        child: Icon(
                          _balanceVisible
                              ? Icons.visibility_outlined
                              : Icons.visibility_off_outlined,
                          color: Colors.white.withValues(alpha: 0.85),
                          size: 18,
                        ),
                      ),
                      const Spacer(),
                      GestureDetector(
                        onTap: _openHistoryModal,
                        child: Icon(
                          Icons.chevron_right_rounded,
                          color: Colors.white.withValues(alpha: 0.85),
                          size: 20,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  AnimatedSwitcher(
                    duration: const Duration(milliseconds: 300),
                    child: _balanceVisible
                        ? Text(
                            'Rp 12.450.000',
                            key: const ValueKey('visible_merchant'),
                            style: AppTheme.font(
                              fontSize: 24,
                              fontWeight: FontWeight.w700,
                              color: Colors.white,
                              letterSpacing: 0.3,
                            ),
                          )
                        : Text(
                            'Rp ••••••••',
                            key: const ValueKey('hidden_merchant'),
                            style: AppTheme.font(
                              fontSize: 24,
                              fontWeight: FontWeight.w700,
                              color: Colors.white,
                              letterSpacing: 0.3,
                            ),
                          ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    'Settlement otomatis ke rekening setiap 23:00 WIB',
                    style: AppTheme.font(
                      fontSize: 10,
                      fontWeight: FontWeight.w400,
                      color: Colors.white.withValues(alpha: 0.75),
                    ),
                  ),
                  const SizedBox(height: 18),
                  // 3 Aksi Merchant Sesuai Request: + Transaksi, Tarik Tunai, Riwayat
                  Row(
                    children: [
                      Expanded(
                        child: _MerchantActionButton(
                          icon: Icons.add_circle_outline_rounded,
                          label: 'Transaksi',
                          onTap: _openNewTransaction,
                        ),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: _MerchantActionButton(
                          icon: Icons.payments_outlined,
                          label: 'Tarik Tunai',
                          onTap: _openWithdrawModal,
                        ),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: _MerchantActionButton(
                          icon: Icons.history_rounded,
                          label: 'Riwayat',
                          onTap: _openHistoryModal,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTodayStats() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 14, 16, 0),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        decoration: BoxDecoration(
          color: AppColors.surface,
          borderRadius: BorderRadius.circular(18),
          boxShadow: [
            BoxShadow(
              color: AppColors.textPrimary.withValues(alpha: 0.04),
              blurRadius: 16,
              offset: const Offset(0, 3),
            ),
          ],
        ),
        child: Row(
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Omset Hari Ini',
                    style: AppTheme.font(
                      fontSize: 11,
                      fontWeight: FontWeight.w500,
                      color: AppColors.textSecondary,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    'Rp 3.850.000',
                    style: AppTheme.font(
                      fontSize: 15,
                      fontWeight: FontWeight.w700,
                      color: AppColors.merchantPrimary,
                    ),
                  ),
                ],
              ),
            ),
            Container(
              height: 28,
              width: 1,
              color: AppColors.divider,
            ),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.only(left: 14),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Transaksi Sukses',
                      style: AppTheme.font(
                        fontSize: 11,
                        fontWeight: FontWeight.w500,
                        color: AppColors.textSecondary,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Row(
                      children: [
                        Text(
                          '42 Pesanan',
                          style: AppTheme.font(
                            fontSize: 15,
                            fontWeight: FontWeight.w700,
                            color: AppColors.textPrimary,
                          ),
                        ),
                        const SizedBox(width: 4),
                        const Icon(Icons.trending_up_rounded, color: AppColors.merchantPrimary, size: 16),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildShortcuts() {
    final shortcuts = [
      _MerchantShortcutData(Icons.point_of_sale_rounded, 'Kasir POS', AppColors.merchantPrimary),
      _MerchantShortcutData(Icons.qr_code_2_rounded, 'QRIS Statis', const Color(0xFF0284C7)),
      _MerchantShortcutData(Icons.account_balance_rounded, 'Tarik Dana', const Color(0xFFE11D48)),
      _MerchantShortcutData(Icons.inventory_2_outlined, 'Produk', const Color(0xFFD97706)),
      _MerchantShortcutData(Icons.bar_chart_rounded, 'Laporan', const Color(0xFF7C3AED)),
      _MerchantShortcutData(Icons.badge_outlined, 'Pegawai', const Color(0xFF059669)),
      _MerchantShortcutData(Icons.discount_outlined, 'Promo Toko', const Color(0xFFEA580C)),
      _MerchantShortcutData(Icons.more_horiz_rounded, 'Lainnya', AppColors.textSecondary),
    ];

    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 14, 16, 0),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: AppColors.surface,
          borderRadius: BorderRadius.circular(20),
          boxShadow: [
            BoxShadow(
              color: AppColors.textPrimary.withValues(alpha: 0.05),
              blurRadius: 18,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Text(
                  'Fitur Bisnis Merchant',
                  style: AppTheme.font(
                    fontSize: 15,
                    fontWeight: FontWeight.w700,
                    color: AppColors.textPrimary,
                  ),
                ),
                const Spacer(),
                Text(
                  'Semua',
                  style: AppTheme.font(
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                    color: AppColors.merchantPrimary,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            // Grid kebawah 4 kolom
            GridView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: shortcuts.length,
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 4,
                mainAxisSpacing: 16,
                crossAxisSpacing: 8,
                childAspectRatio: 0.88,
              ),
              itemBuilder: (context, index) {
                return _MerchantShortcutItem(data: shortcuts[index]);
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildPromoSection() {
    final promos = [
      _MerchantPromoCardData(
        color: AppColors.merchantPrimary,
        title: 'MDR 0% Transaksi QRIS',
        subtitle: 'Bebas potongan transaksi QRIS khusus usaha mikro s/d akhir tahun.',
        icon: Icons.qr_code_scanner_rounded,
        tag: 'Promo UMKM',
      ),
      _MerchantPromoCardData(
        color: const Color(0xFF0284C7),
        title: 'Modal Usaha s/d 100 Juta',
        subtitle: 'Ajukan pembiayaan usaha instan dengan bunga ringan khusus merchant aktif.',
        icon: Icons.savings_outlined,
        tag: 'Finansial',
      ),
      _MerchantPromoCardData(
        color: const Color(0xFFEA580C),
        title: 'Cetak Struk Bluetooth',
        subtitle: 'Hubungkan printer thermal kasir langsung dari aplikasi ReyPay Merchant.',
        icon: Icons.print_rounded,
        tag: 'Fitur Baru',
      ),
    ];

    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 18, 16, 0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Text(
                'Info & Keuntungan Merchant',
                style: AppTheme.font(
                  fontSize: 15,
                  fontWeight: FontWeight.w700,
                  color: AppColors.textPrimary,
                ),
              ),
              const Spacer(),
              Text(
                'Lihat semua',
                style: AppTheme.font(
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                  color: AppColors.merchantPrimary,
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          // List menurun ke bawah
          ListView.separated(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: promos.length,
            separatorBuilder: (context, index) => const SizedBox(height: 10),
            itemBuilder: (_, index) => _MerchantPromoVerticalCard(data: promos[index]),
          ),
        ],
      ),
    );
  }

  Widget _buildRecentTransactions() {
    final transactions = [
      _MerchantTxData(
        'QRIS BCA - Meja 03',
        'Pembayaran Berhasil',
        '+Rp 85.000',
        '3 menit lalu',
        'QRIS Dinamis',
      ),
      _MerchantTxData(
        'QRIS GoPay - Takeaway',
        'Pembayaran Berhasil',
        '+Rp 32.000',
        '18 menit lalu',
        'QRIS Statis',
      ),
      _MerchantTxData(
        'QRIS Mandiri - Meja 07',
        'Pembayaran Berhasil',
        '+Rp 145.000',
        '42 menit lalu',
        'Kasir POS',
      ),
      _MerchantTxData(
        'QRIS Dana - Minuman',
        'Pembayaran Berhasil',
        '+Rp 25.000',
        '1 jam lalu',
        'QRIS Statis',
      ),
    ];

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 20, 16, 12),
          child: Row(
            children: [
              Text(
                'Transaksi Pelanggan Masuk',
                style: AppTheme.font(
                  fontSize: 15,
                  fontWeight: FontWeight.w700,
                  color: AppColors.textPrimary,
                ),
              ),
              const Spacer(),
              GestureDetector(
                onTap: _openHistoryModal,
                child: Text(
                  'Lihat semua',
                  style: AppTheme.font(
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                    color: AppColors.merchantPrimary,
                  ),
                ),
              ),
            ],
          ),
        ),
        Container(
          margin: const EdgeInsets.symmetric(horizontal: 16),
          decoration: BoxDecoration(
            color: AppColors.surface,
            borderRadius: BorderRadius.circular(20),
            boxShadow: [
              BoxShadow(
                color: AppColors.textPrimary.withValues(alpha: 0.05),
                blurRadius: 18,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: Column(
            children: List.generate(transactions.length, (i) {
              return Column(
                children: [
                  _MerchantTransactionTile(data: transactions[i]),
                  if (i < transactions.length - 1)
                    const Divider(
                      height: 1,
                      indent: 72,
                      endIndent: 20,
                      color: AppColors.divider,
                    ),
                ],
              );
            }),
          ),
        ),
      ],
    );
  }
}

// ─── REUSABLE MERCHANT WIDGETS ──────────────────────────────────────────────

class _MerchantAppBarButton extends StatelessWidget {
  final IconData icon;
  final int? badge;
  final VoidCallback onTap;

  const _MerchantAppBarButton({
    required this.icon,
    required this.onTap,
    this.badge,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Stack(
        clipBehavior: Clip.none,
        alignment: Alignment.center,
        children: [
          Container(
            width: 36,
            height: 36,
            color: Colors.transparent,
            alignment: Alignment.center,
            child: Icon(
              icon,
              color: AppColors.textPrimary,
              size: 24,
            ),
          ),
          if (badge != null)
            Positioned(
              right: 1,
              top: 1,
              child: Container(
                width: 14,
                height: 14,
                decoration: const BoxDecoration(
                  color: AppColors.error,
                  shape: BoxShape.circle,
                ),
                alignment: Alignment.center,
                child: Text(
                  '$badge',
                  style: AppTheme.font(
                    fontSize: 8,
                    fontWeight: FontWeight.w700,
                    color: Colors.white,
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}

class _MerchantActionButton extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;

  const _MerchantActionButton({
    required this.icon,
    required this.label,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 10),
        decoration: BoxDecoration(
          color: Colors.white.withValues(alpha: 0.18),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: Colors.white.withValues(alpha: 0.2),
            width: 1,
          ),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              icon,
              color: Colors.white,
              size: 16,
            ),
            const SizedBox(width: 5),
            Flexible(
              child: Text(
                label,
                overflow: TextOverflow.ellipsis,
                style: AppTheme.font(
                  fontSize: 11,
                  fontWeight: FontWeight.w700,
                  color: Colors.white,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _MerchantShortcutData {
  final IconData icon;
  final String label;
  final Color color;

  const _MerchantShortcutData(this.icon, this.label, this.color);
}

class _MerchantShortcutItem extends StatelessWidget {
  final _MerchantShortcutData data;

  const _MerchantShortcutItem({required this.data});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {},
      child: Column(
        mainAxisSize: MainAxisSize.min,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          // Squircle icon shape
          Container(
            width: 50,
            height: 50,
            decoration: BoxDecoration(
              color: data.color.withValues(alpha: 0.12),
              borderRadius: BorderRadius.circular(16), // SQUIRCLE
            ),
            child: Icon(data.icon, color: data.color, size: 24),
          ),
          const SizedBox(height: 6),
          Text(
            data.label,
            textAlign: TextAlign.center,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: AppTheme.font(
              fontSize: 11,
              fontWeight: FontWeight.w500,
              color: AppColors.textSecondary,
            ),
          ),
        ],
      ),
    );
  }
}

class _MerchantPromoCardData {
  final Color color;
  final String title;
  final String subtitle;
  final IconData icon;
  final String tag;

  const _MerchantPromoCardData({
    required this.color,
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.tag,
  });
}

class _MerchantPromoVerticalCard extends StatelessWidget {
  final _MerchantPromoCardData data;

  const _MerchantPromoVerticalCard({required this.data});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: AppColors.textPrimary.withValues(alpha: 0.04),
            blurRadius: 14,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(
              color: data.color.withValues(alpha: 0.12),
              borderRadius: BorderRadius.circular(14),
            ),
            child: Icon(data.icon, color: data.color, size: 24),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Expanded(
                      child: Text(
                        data.title,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: AppTheme.font(
                          fontSize: 13,
                          fontWeight: FontWeight.w700,
                          color: AppColors.textPrimary,
                        ),
                      ),
                    ),
                    const SizedBox(width: 6),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
                      decoration: BoxDecoration(
                        color: data.color.withValues(alpha: 0.12),
                        borderRadius: BorderRadius.circular(6),
                      ),
                      child: Text(
                        data.tag,
                        style: AppTheme.font(
                          fontSize: 10,
                          fontWeight: FontWeight.w700,
                          color: data.color,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 4),
                Text(
                  data.subtitle,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: AppTheme.font(
                    fontSize: 11,
                    fontWeight: FontWeight.w400,
                    color: AppColors.textSecondary,
                    height: 1.4,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 4),
          const Icon(
            Icons.chevron_right_rounded,
            color: AppColors.textLight,
            size: 20,
          ),
        ],
      ),
    );
  }
}

class _MerchantTxData {
  final String title;
  final String status;
  final String amount;
  final String time;
  final String method;

  const _MerchantTxData(
    this.title,
    this.status,
    this.amount,
    this.time,
    this.method,
  );
}

class _MerchantTransactionTile extends StatelessWidget {
  final _MerchantTxData data;

  const _MerchantTransactionTile({required this.data});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      child: Row(
        children: [
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              color: AppColors.merchantLightGreen,
              borderRadius: BorderRadius.circular(14),
            ),
            child: const Icon(
              Icons.qr_code_2_rounded,
              color: AppColors.merchantPrimary,
              size: 22,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  data.title,
                  style: AppTheme.font(
                    fontSize: 13,
                    fontWeight: FontWeight.w700,
                    color: AppColors.textPrimary,
                  ),
                ),
                const SizedBox(height: 2),
                Row(
                  children: [
                    Text(
                      data.method,
                      style: AppTheme.font(
                        fontSize: 11,
                        fontWeight: FontWeight.w500,
                        color: AppColors.merchantPrimary,
                      ),
                    ),
                    Text(
                      ' • ${data.time}',
                      style: AppTheme.font(
                        fontSize: 11,
                        fontWeight: FontWeight.w400,
                        color: AppColors.textLight,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          Text(
            data.amount,
            style: AppTheme.font(
              fontSize: 14,
              fontWeight: FontWeight.w700,
              color: AppColors.merchantPrimary,
            ),
          ),
        ],
      ),
    );
  }
}

class _MerchantNavItem extends StatelessWidget {
  final IconData icon;
  final String label;
  final bool isActive;
  final VoidCallback onTap;

  const _MerchantNavItem({
    required this.icon,
    required this.label,
    required this.isActive,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      behavior: HitTestBehavior.opaque,
      child: SizedBox(
        width: 72,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            AnimatedContainer(
              duration: const Duration(milliseconds: 250),
              curve: Curves.easeOut,
              width: 44,
              height: 36,
              decoration: BoxDecoration(
                color: isActive
                    ? AppColors.merchantPrimary.withValues(alpha: 0.12)
                    : Colors.transparent,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(
                icon,
                color: isActive ? AppColors.merchantPrimary : AppColors.textLight,
                size: 22,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              label,
              style: AppTheme.font(
                fontSize: 10,
                fontWeight: isActive ? FontWeight.w700 : FontWeight.w400,
                color: isActive ? AppColors.merchantPrimary : AppColors.textLight,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ─── MODALS: TRANSAKSI BARU, TARIK DANA, RIWAYAT ─────────────────────────────

class _NewTransactionModal extends StatefulWidget {
  const _NewTransactionModal();

  @override
  State<_NewTransactionModal> createState() => _NewTransactionModalState();
}

class _NewTransactionModalState extends State<_NewTransactionModal> {
  final _amountController = TextEditingController(text: '50.000');
  bool _isGenerated = false;

  final List<String> _quickAmounts = ['15.000', '25.000', '50.000', '100.000'];

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.only(
        bottom: MediaQuery.of(context).viewInsets.bottom,
      ),
      decoration: const BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
      ),
      child: SafeArea(
        top: false,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 12, 20, 24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              // Drag handle
              Container(
                width: 40,
                height: 4,
                decoration: BoxDecoration(
                  color: AppColors.divider,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
              const SizedBox(height: 18),
              Row(
                children: [
                  Container(
                    width: 36,
                    height: 36,
                    decoration: BoxDecoration(
                      color: AppColors.merchantLightGreen,
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: const Icon(
                      Icons.add_task_rounded,
                      color: AppColors.merchantPrimary,
                      size: 20,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Text(
                    'Buat Tagihan QRIS Baru',
                    style: AppTheme.font(
                      fontSize: 17,
                      fontWeight: FontWeight.w700,
                      color: AppColors.textPrimary,
                    ),
                  ),
                  const Spacer(),
                  GestureDetector(
                    onTap: () => Navigator.pop(context),
                    child: const Icon(Icons.close_rounded, color: AppColors.textSecondary),
                  ),
                ],
              ),
              const SizedBox(height: 20),
              if (!_isGenerated) ...[
                // Input Nominal
                Text(
                  'Masukkan Nominal Pembayaran',
                  style: AppTheme.font(
                    fontSize: 12,
                    fontWeight: FontWeight.w500,
                    color: AppColors.textSecondary,
                  ),
                ),
                const SizedBox(height: 8),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                  decoration: BoxDecoration(
                    color: AppColors.merchantBackground,
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: AppColors.merchantPrimary, width: 1.5),
                  ),
                  child: Row(
                    children: [
                      Text(
                        'Rp',
                        style: AppTheme.font(
                          fontSize: 20,
                          fontWeight: FontWeight.w700,
                          color: AppColors.merchantPrimary,
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: TextField(
                          controller: _amountController,
                          keyboardType: TextInputType.number,
                          style: AppTheme.font(
                            fontSize: 22,
                            fontWeight: FontWeight.w700,
                            color: AppColors.textPrimary,
                          ),
                          decoration: const InputDecoration(
                            border: InputBorder.none,
                            enabledBorder: InputBorder.none,
                            focusedBorder: InputBorder.none,
                            contentPadding: EdgeInsets.zero,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 14),
                // Tombol Cepat
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: _quickAmounts.map((amt) {
                    return GestureDetector(
                      onTap: () => setState(() => _amountController.text = amt),
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                        decoration: BoxDecoration(
                          color: AppColors.merchantLightGreen,
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Text(
                          amt,
                          style: AppTheme.font(
                            fontSize: 12,
                            fontWeight: FontWeight.w600,
                            color: AppColors.merchantPrimary,
                          ),
                        ),
                      ),
                    );
                  }).toList(),
                ),
                const SizedBox(height: 24),
                SizedBox(
                  width: double.infinity,
                  height: 50,
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppColors.merchantPrimary,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                      elevation: 0,
                    ),
                    onPressed: () => setState(() => _isGenerated = true),
                    child: Text(
                      'Tampilkan QRIS Pelanggan',
                      style: AppTheme.font(
                        fontSize: 14,
                        fontWeight: FontWeight.w700,
                        color: Colors.white,
                      ),
                    ),
                  ),
                ),
              ] else ...[
                // Tampilan QRIS yang Digenerate
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: AppColors.surface,
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: AppColors.divider, width: 1.5),
                  ),
                  child: Column(
                    children: [
                      Text(
                        'Total: Rp ${_amountController.text}',
                        style: AppTheme.font(
                          fontSize: 18,
                          fontWeight: FontWeight.w700,
                          color: AppColors.merchantPrimary,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        'Scan dengan GoPay, OVO, Dana, BCA, Livin, dll',
                        style: AppTheme.font(fontSize: 11, color: AppColors.textSecondary),
                      ),
                      const SizedBox(height: 16),
                      Container(
                        width: 190,
                        height: 190,
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(16),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withValues(alpha: 0.06),
                              blurRadius: 10,
                            ),
                          ],
                        ),
                        child: const Icon(
                          Icons.qr_code_2_rounded,
                          size: 170,
                          color: AppColors.textPrimary,
                        ),
                      ),
                      const SizedBox(height: 12),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const Icon(Icons.timer_outlined, size: 14, color: AppColors.textSecondary),
                          const SizedBox(width: 4),
                          Text(
                            'Berlaku selama 04:59',
                            style: AppTheme.font(fontSize: 11, color: AppColors.textSecondary),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 20),
                SizedBox(
                  width: double.infinity,
                  height: 48,
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppColors.merchantPrimary,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                      elevation: 0,
                    ),
                    onPressed: () {
                      Navigator.pop(context);
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                          content: Text('Pembayaran QRIS Berhasil Diterima! +Rp 50.000'),
                          backgroundColor: AppColors.merchantPrimary,
                        ),
                      );
                    },
                    child: Text(
                      'Simulasi Pembayaran Berhasil',
                      style: AppTheme.font(
                        fontSize: 14,
                        fontWeight: FontWeight.w700,
                        color: Colors.white,
                      ),
                    ),
                  ),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}

class _WithdrawModal extends StatelessWidget {
  const _WithdrawModal();

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
      ),
      child: SafeArea(
        top: false,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 14, 20, 24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Container(
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(
                    color: AppColors.divider,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ),
              const SizedBox(height: 18),
              Text(
                'Tarik Tunai / Settlement',
                style: AppTheme.font(
                  fontSize: 18,
                  fontWeight: FontWeight.w700,
                  color: AppColors.textPrimary,
                ),
              ),
              const SizedBox(height: 6),
              Text(
                'Tarik dana pendapatan merchant langsung ke rekening bank utama.',
                style: AppTheme.font(fontSize: 12, color: AppColors.textSecondary),
              ),
              const SizedBox(height: 16),
              Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: AppColors.merchantLightGreen,
                  borderRadius: BorderRadius.circular(14),
                ),
                child: Row(
                  children: [
                    const Icon(Icons.account_balance_rounded, color: AppColors.merchantPrimary),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'ReyBank • Rekening Penampungan',
                            style: AppTheme.font(fontSize: 11, color: AppColors.textSecondary),
                          ),
                          Text(
                            '3210 4821 9012 (Reyhan Pratama)',
                            style: AppTheme.font(fontSize: 13, fontWeight: FontWeight.w700, color: AppColors.textPrimary),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 20),
              SizedBox(
                width: double.infinity,
                height: 48,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppColors.merchantPrimary,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                    elevation: 0,
                  ),
                  onPressed: () {
                    Navigator.pop(context);
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text('Permintaan Tarik Tunai Berhasil Diproses!'),
                        backgroundColor: AppColors.merchantPrimary,
                      ),
                    );
                  },
                  child: Text(
                    'Tarik Saldo Rp 12.450.000',
                    style: AppTheme.font(fontSize: 14, fontWeight: FontWeight.w700, color: Colors.white),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _TransactionHistoryModal extends StatelessWidget {
  const _TransactionHistoryModal();

  @override
  Widget build(BuildContext context) {
    return Container(
      height: MediaQuery.of(context).size.height * 0.7,
      decoration: const BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
      ),
      child: SafeArea(
        top: false,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 14, 20, 16),
          child: Column(
            children: [
              Container(
                width: 40,
                height: 4,
                decoration: BoxDecoration(
                  color: AppColors.divider,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
              const SizedBox(height: 18),
              Row(
                children: [
                  Text(
                    'Riwayat Transaksi Toko',
                    style: AppTheme.font(
                      fontSize: 18,
                      fontWeight: FontWeight.w700,
                      color: AppColors.textPrimary,
                    ),
                  ),
                  const Spacer(),
                  GestureDetector(
                    onTap: () => Navigator.pop(context),
                    child: const Icon(Icons.close_rounded, color: AppColors.textSecondary),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              Expanded(
                child: ListView(
                  physics: const ClampingScrollPhysics(),
                  children: const [
                    _MerchantTransactionTile(
                      data: _MerchantTxData('QRIS BCA - Meja 03', 'Sukses', '+Rp 85.000', '3 mnt lalu', 'QRIS Dinamis'),
                    ),
                    _MerchantTransactionTile(
                      data: _MerchantTxData('QRIS GoPay - Takeaway', 'Sukses', '+Rp 32.000', '18 mnt lalu', 'QRIS Statis'),
                    ),
                    _MerchantTransactionTile(
                      data: _MerchantTxData('QRIS Mandiri - Meja 07', 'Sukses', '+Rp 145.000', '42 mnt lalu', 'Kasir POS'),
                    ),
                    _MerchantTransactionTile(
                      data: _MerchantTxData('QRIS Dana - Minuman', 'Sukses', '+Rp 25.000', '1 jam lalu', 'QRIS Statis'),
                    ),
                    _MerchantTransactionTile(
                      data: _MerchantTxData('Settlement Bank Otomatis', 'Berhasil Ditransfer', '-Rp 8.400.000', 'Kemarin 23:00', 'Bank Settlement'),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ─── PLACEHOLDER PAGES MERCHANT ─────────────────────────────────────────────

class _MerchantReportsPage extends StatelessWidget {
  const _MerchantReportsPage();

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: 76,
            height: 76,
            decoration: BoxDecoration(
              color: AppColors.merchantLightGreen,
              borderRadius: BorderRadius.circular(22),
            ),
            child: const Icon(Icons.bar_chart_rounded, color: AppColors.merchantPrimary, size: 36),
          ),
          const SizedBox(height: 18),
          Text(
            'Laporan Keuangan Toko',
            style: AppTheme.font(fontSize: 18, fontWeight: FontWeight.w700, color: AppColors.textPrimary),
          ),
          const SizedBox(height: 6),
          Text(
            'Grafik omset harian, mingguan, dan bulanan',
            style: AppTheme.font(fontSize: 13, color: AppColors.textSecondary),
          ),
        ],
      ),
    );
  }
}

class _MerchantProductsPage extends StatelessWidget {
  const _MerchantProductsPage();

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: 76,
            height: 76,
            decoration: BoxDecoration(
              color: AppColors.merchantLightGreen,
              borderRadius: BorderRadius.circular(22),
            ),
            child: const Icon(Icons.inventory_2_outlined, color: AppColors.merchantPrimary, size: 36),
          ),
          const SizedBox(height: 18),
          Text(
            'Katalog & Produk',
            style: AppTheme.font(fontSize: 18, fontWeight: FontWeight.w700, color: AppColors.textPrimary),
          ),
          const SizedBox(height: 6),
          Text(
            'Kelola menu makanan, minuman, dan stok kasir',
            style: AppTheme.font(fontSize: 13, color: AppColors.textSecondary),
          ),
        ],
      ),
    );
  }
}

class _MerchantSettingsPage extends StatelessWidget {
  final VoidCallback? onLogout;
  const _MerchantSettingsPage({this.onLogout});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: 76,
            height: 76,
            decoration: BoxDecoration(
              color: AppColors.merchantLightGreen,
              borderRadius: BorderRadius.circular(22),
            ),
            child: const Icon(Icons.store_mall_directory_outlined, color: AppColors.merchantPrimary, size: 36),
          ),
          const SizedBox(height: 18),
          Text(
            'Pengaturan Toko',
            style: AppTheme.font(fontSize: 18, fontWeight: FontWeight.w700, color: AppColors.textPrimary),
          ),
          const SizedBox(height: 6),
          Text(
            'Jam operasional, printer thermal, dan pegawai',
            style: AppTheme.font(fontSize: 13, color: AppColors.textSecondary),
          ),
          if (onLogout != null) ...[
            const SizedBox(height: 24),
            OutlinedButton.icon(
              style: OutlinedButton.styleFrom(
                foregroundColor: AppColors.error,
                side: const BorderSide(color: AppColors.error),
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
              onPressed: onLogout,
              icon: const Icon(Icons.logout_rounded, size: 18),
              label: Text(
                'Keluar Akun Merchant',
                style: AppTheme.font(
                  fontSize: 13,
                  fontWeight: FontWeight.w600,
                  color: AppColors.error,
                ),
              ),
            ),
          ],
        ],
      ),
    );
  }
}
